## Fiqri project

**Clone Repo:**  
```pompt
git clone git@github.com:Fransis96/perpus.git
```

**Login Admin:**
- username ``admin``  
- password ``a``  

**Login User:**  
- username ``lin``  
- password ``lin``  

- username ``agnes``  
- password ``ai``

